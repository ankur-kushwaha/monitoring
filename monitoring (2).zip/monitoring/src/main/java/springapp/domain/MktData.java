package springapp.domain;

public class MktData {

}
