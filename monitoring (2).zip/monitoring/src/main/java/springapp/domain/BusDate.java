package springapp.domain;

public class BusDate {
	String subArea;
	String businessDate;
	String expectedBusDate;
	public String getSubArea() {
		return subArea;
	}
	public void setSubArea(String subArea) {
		this.subArea = subArea;
	}
	public String getBusinessDate() {
		return businessDate;
	}
	public void setBusinessDate(String businessDate) {
		this.businessDate = businessDate;
	}
	public String getExpectedBusDate() {
		return expectedBusDate;
	}
	public void setExpectedBusDate(String expectedBusDate) {
		this.expectedBusDate = expectedBusDate;
	}
}
