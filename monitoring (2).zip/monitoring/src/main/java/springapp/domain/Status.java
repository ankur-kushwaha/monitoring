package springapp.domain;
public class Status{
	String subarea;
	String sbd;
	String fbd;
	String status;
	public String getSubarea() {
		return subarea;
	}
	public void setSubarea(String subarea) {
		this.subarea = subarea;
	}
	public String getSbd() {
		return sbd;
	}
	public void setSbd(String sbd) {
		this.sbd = sbd;
	}
	public String getFbd() {
		return fbd;
	}
	public void setFbd(String fbd) {
		this.fbd = fbd;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
